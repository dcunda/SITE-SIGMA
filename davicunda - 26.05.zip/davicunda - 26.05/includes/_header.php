<?php



?>

<header>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="artigos.php">Empresa</a></li>
            <li><a href="produtos-categoria.php">Produtos</a></li>
            <li><a href="contato.php">Contato</a></li>
        </ul>
    </nav>

</header>
<main>


